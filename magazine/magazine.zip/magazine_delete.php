<?php
	echo <<<_END
		<html>
			<head>
				<title>Magazine Delete</title>
				<link rel='stylesheet' href='../styles.css'>
			</head>
			<body>
				<a>
					<br>
					<center>
					<img height='100' width='200' src='../images/library_logo.jpg'></img>
					</center>
					<br>
					<br>
				</a>
			</body>
		</html>
	_END;
?>